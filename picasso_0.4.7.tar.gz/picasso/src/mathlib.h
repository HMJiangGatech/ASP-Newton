#ifndef MATHLIB_STANDALONE
#define MATHLIB_STANDALONE
#include "Rmath.h"

void set_seed(unsigned int, unsigned int);

#endif
